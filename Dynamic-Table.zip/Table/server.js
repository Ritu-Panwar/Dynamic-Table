// Import necessary modules
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

// Create Express app
const app = express();

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/table_data', {
}).then(() => {
  console.log("Connected to MongoDB");
}).catch((error) => {
  console.error("Error connecting to MongoDB:", error);
});

// Define schema
const tableSchema = new mongoose.Schema({
  Sr_No: String,
  Name: String,
  Roll_No: String,
  LOS_CO1: String,
  LOS_CO2: String,
  LOS_Percentage: String,
  ECommerce_CO1: String,
  ECommerce_CO2: String,
  ECommerce_Percentage: String,
  Software_CO1: String,
  Software_CO2: String,
  Software_Percentage: String,
  ADA_CO1: String,
  ADA_CO2: String,
  ADA_Percentage: String,
  MC_CO1: String,
  MC_CO2: String,
  MC_Percentage: String,
  BDA_CO1: String,
  BDA_CO2: String,
  BDA_Percentage: String,
  DWDM_CO1: String,
  DWDM_CO2: String,
  DWDM_Percentage: String,
  Total_Marks: String,
  Total_Percentage: String
});

const table1Schema = new mongoose.Schema({
  Sr_No: String,
  Name: String,
  Roll_No: String,
  LOS_CO3: String,
  LOS_CO4: String,
  LOS_Percentage: String,
  ECommerce_CO3: String,
  ECommerce_CO4: String,
  ECommerce_Percentage: String,
  Software_CO3: String,
  Software_CO4: String,
  Software_Percentage: String,
  ADA_CO3: String,
  ADA_CO4: String,
  ADA_Percentage: String,
  MC_CO3: String,
  MC_CO4: String,
  MC_Percentage: String,
  BDA_CO3: String,
  BDA_CO4: String,
  BDA_Percentage: String,
  DWDM_CO3: String,
  DWDM_CO4: String,
  DWDM_Percentage: String,
  Total_Marks: String,
  Total_Percentage: String
});

const table2Schema = new mongoose.Schema({
  Sr_No: String,
  Name: String,
  Roll_No: String,
  LOS_Marks: String,
  ECommerce_Marks: String,
  Software_Marks: String,
  ADA_Marks: String,
  MC_Marks: String,
  BDA_Marks: String,
  DWDM_Marks: String,
  Total_Marks: String,
  Total_Percentage: String
});

const attendanceSchema = new mongoose.Schema({
  Sr_No: String,
  Name: String,
  Roll_No: String,
  Upto_S1: String,
  Upto_S2: String,
  Upto_S3: String,
  Total_Percentage: String
});

// Create model from schema
const Table = mongoose.model('Table', tableSchema);
const Table1 = mongoose.model('Table1', table1Schema);
const Table2 = mongoose.model('Table2', table2Schema);
const Attendance = mongoose.model('attendance', attendanceSchema);

// Middleware
app.use(bodyParser.json());

// Serve static files (assuming index.html is in the public directory)
app.use(express.static('public'));

// Route to handle GET request for fetching data from MongoDB
app.get('/api/table', async (req, res) => {
  try {
    const data = await Table.find(); // Fetch all data from MongoDB
    res.json(data); // Respond with fetched data
  } catch (error) {
    console.error("Error fetching data:", error);
    res.status(500).json({ message: 'Server error' });
  }
});

app.get('/api/table1', async (req, res) => {
  try {
    const data = await Table1.find(); // Fetch all data from MongoDB
    res.json(data); // Respond with fetched data
  } catch (error) {
    console.error("Error fetching data:", error);
    res.status(500).json({ message: 'Server error' });
  }
});

app.get('/api/table2', async (req, res) => {
  try {
    const data = await Table2.find(); // Fetch all data from MongoDB
    res.json(data); // Respond with fetched data
  } catch (error) {
    console.error("Error fetching data:", error);
    res.status(500).json({ message: 'Server error' });
  }
});

app.get('/api/attendance', async (req, res) => {
  try {
    const data = await Attendance.find(); // Fetch all data from MongoDB
    res.json(data); // Respond with fetched data
  } catch (error) {
    console.error("Error fetching data:", error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Route to handle POST request for saving data to MongoDB
app.post('/api/table', async (req, res) => {
  try {
    const newData = req.body; // Get data from request body
    await Table.deleteMany({}); // Clear existing data in MongoDB
    const savedData = await Table.insertMany(newData); // Save new data to MongoDB
    res.status(201).json(savedData); // Respond with saved data
  } catch (error) {
    console.error("Error saving data:", error);
    res.status(500).json({ message: 'Server error' });
  }
});

app.post('/api/table1', async (req, res) => {
  try {
    const newData = req.body; // Get data from request body
    await Table1.deleteMany({}); // Clear existing data in MongoDB
    const savedData = await Table1.insertMany(newData); // Save new data to MongoDB
    res.status(201).json(savedData); // Respond with saved data
  } catch (error) {
    console.error("Error saving data:", error);
    res.status(500).json({ message: 'Server error' });
  }
});

app.post('/api/table2', async (req, res) => {
  try {
    const newData = req.body; // Get data from request body
    await Table2.deleteMany({}); // Clear existing data in MongoDB
    const savedData = await Table2.insertMany(newData); // Save new data to MongoDB
    res.status(201).json(savedData); // Respond with saved data
  } catch (error) {
    console.error("Error saving data:", error);
    res.status(500).json({ message: 'Server error' });
  }
});

app.post('/api/attendance', async (req, res) => {
  try {
    const newData = req.body; // Get data from request body
    await Attendance.deleteMany({}); // Clear existing data in MongoDB
    const savedData = await Attendance.insertMany(newData); // Save new data to MongoDB
    res.status(201).json(savedData); // Respond with saved data
  } catch (error) {
    console.error("Error saving data:", error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
